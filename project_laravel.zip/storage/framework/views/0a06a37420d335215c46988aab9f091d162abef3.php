
<?php $__env->startSection('main'); ?>
<div class="nk-main">
        
    <!-- START: Breadcrumbs -->
<div class="nk-gap-1"></div>
<div class="container">
<ul class="nk-breadcrumbs">


<li><a href="index.html">Home</a></li>


<li><span class="fa fa-angle-right"></span></li>

<li><span>Elements</span></li>

</ul>
</div>
<div class="nk-gap-1"></div>
<!-- END: Breadcrumbs -->




<div class="container">
<div class="row vertical-gap">
    <div class="col-lg-4">
        <!-- START: Headings -->
        <h3 class="text-main-1">Headings</h3>
        <div class="nk-gap"></div>
        <h1>h1 Heading</h1>
        <h2>h2 Heading</h2>
        <h3>h3 Heading</h3>
        <h4>h4 Heading</h4>
        <h5>h5 Heading</h5>
        <h6>h6 Heading</h6>
        <!-- END: Headings -->
    </div>
    <div class="col-lg-8">
        <!-- START: Paragraphs -->
        <h3 class="text-main-1">Paragraphs</h3>
        <div class="nk-gap"></div>
        <p><strong>Paragraph</strong> - which was concealed with great care and some a pewter platter of unusual dimensions. This mighty dish he placed before his guest, who, using his poniard to cut it ope, lost no time in making himself acquainted with its contents hich was concealed with great care and some a pewter platter of unusual.</p>
        <p class="lead"><strong>Lead Paragraph</strong> - it was some time before he obtained any answer, and the reply, when made, was unpropitious hich was concealed with great care and some a pewter platter of unusual.</p>
        <p class="text-white"><strong>White Paragraph</strong> - who at last turned sulky, and would only say, `I am older than you, and must know better'; and this Alice would not allow without knowing how old it was, and, as the Lory positively refused to tell its age.</p>
        <!-- END: Paragraphs -->
    </div>
</div>

<!-- START: Decorated Headings -->
<div class="nk-gap-2"></div>
<h3><span class="text-main-1">Decorated</span> Headings</h3>
<div class="nk-gap"></div>
<h3 class="nk-decorated-h"><span><span class="text-main-1">Heading</span> #1</span></h3>
<h3 class="nk-decorated-h-2"><span>Heading #2</span></h3>
<h3 class="nk-decorated-h-3"><span>Heading #3</span></h3>
<!-- END: Decorated Headings -->

<div class="nk-gap-2"></div>
<div class="row vertical-gap">
    <div class="col-lg-7">
        <h3 class="text-main-1">Tabs</h3>
        <div class="nk-gap"></div>
        <!-- START: Tabs  -->
        <div class="nk-tabs">
            <!--
                Additional Classes:
                    .nav-tabs-fill
            -->
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" href="#tabs-1-1" role="tab" data-toggle="tab">Tab 1</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#tabs-1-2" role="tab" data-toggle="tab">Tab 2</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#tabs-1-3" role="tab" data-toggle="tab">Tab 3</a>
                </li>
            </ul>
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade show active" id="tabs-1-1">
                    <div class="nk-gap"></div>
                    <p>I have related the substance of several conversations I had with my master during the greatest part of the time I had the, for brevity sake, omitted much moredown.</p>
                    <p>And she went on planning to herself how she would manage it. 'They must go by the carrier' she thought; and how funny it'll seem And she went on planning to herself how</p>
                    <div class="nk-gap"></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tabs-1-2">
                    <div class="nk-gap"></div>
                    <p>And she went on planning to herself how she would manage it. 'They must go by the carrier' she thought; and how funny it'll seem And she went on planning to herself how</p>
                    <div class="nk-gap"></div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="tabs-1-3">
                    <div class="nk-gap"></div>
                    <p>I have related the substance of several conversations I had with my master during the greatest part of the time I had the, for brevity sake, omitted much moredown.</p>
                    <div class="nk-gap"></div>
                </div>
            </div>
        </div>
        <!-- END: Tabs -->
    </div>
    <div class="col-lg-5">
        <!-- START: Text-Level Semantics -->
        <h3><span class="text-main-1">Text-Level</span> Semantics</h3>
        <div class="nk-gap"></div>
        <div class="row">
            <div class="col-lg-6">
                <h4>&lt;UL> Elements</h4>
                <div class="nk-gap"></div>

                <ul class="text-main-1 pl-20">
                    <li><strong class="text-white">Item 1</strong></li>
                    <li><strong class="text-white">Item 2</strong>
                        <ul>
                            <li><span class="text-white">Item 1</span></li>
                            <li><span class="text-white">Item 2</span>
                                <ul>
                                    <li><span class="text-white">Item 1</span></li>
                                    <li><span class="text-white">Item 2</span></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="col-lg-6">
                <h4>&lt;OL> Elements</h4>
                <div class="nk-gap"></div>

                <ol class="text-main-1 pl-20">
                    <li><strong class="text-white">Item 1</strong></li>
                    <li><strong class="text-white">Item 2</strong>
                        <ol>
                            <li><span class="text-white">Item 1</span></li>
                            <li><span class="text-white">Item 2</span>
                                <ol>
                                    <li><span class="text-white">Item 1</span></li>
                                    <li><span class="text-white">Item 2</span></li>
                                </ol>
                            </li>
                        </ol>
                    </li>
                </ol>
            </div>
        </div>
        <!-- END: Text-Level Semantics -->
    </div>
</div>

<div class="nk-gap-2"></div>
<div class="row vertical-gap">
    <div class="col-lg-7">
        <!-- START: Accordion 1 -->
        <h3 class="text-main-1">Accordion</h3>
        <div class="nk-gap"></div>
        <div class="nk-accordion" id="accordion-1" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="accordion-1-1-heading">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordion-1" href="#accordion-1-1" aria-expanded="true" aria-controls="accordion-1-1">
                        Collapsible 1 <span class="panel-heading-arrow fa fa-angle-down"></span>
                    </a>
                </div>
                <div id="accordion-1-1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="accordion-1-1-heading">
                    <p>I have related the substance of several conversations I had with my master during the greatest part of the time I had the, for brevity sake, omitted much moredown.</p>
                    <p>And she went on planning to herself how she would manage it. 'They must go by the carrier' she thought; and how funny it'll seem And she went on planning to herself how</p>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="accordion-1-2-heading">
                    <a data-toggle="collapse" data-parent="#accordion-1" href="#accordion-1-2" aria-expanded="false" aria-controls="accordion-1-2">
                        Collapsible 2 <span class="panel-heading-arrow fa fa-angle-down"></span>
                    </a>
                </div>
                <div id="accordion-1-2" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="accordion-1-2-heading">
                    <p>And she went on planning to herself how she would manage it. 'They must go by the carrier' she thought; and how funny it'll seem And she went on planning to herself how</p>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="accordion-1-3-heading">
                    <a class="collapsed" data-toggle="collapse" data-parent="#accordion-1" href="#accordion-1-3" aria-expanded="false" aria-controls="accordion-1-3">
                        Collapsible 3 <span class="panel-heading-arrow fa fa-angle-down"></span>
                    </a>
                </div>
                <div id="accordion-1-3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="accordion-1-3-heading">
                    <p>I have related the substance of several conversations I had with my master during the greatest part of the time I had the, for brevity sake, omitted much moredown.</p>
                </div>
            </div>
        </div>
        <!-- END: Accordion 1 -->

        <!-- START: Blockquote -->
        <div class="nk-gap-2"></div>
        <h3 class="text-main-1">Quote</h3>
        <div class="nk-gap"></div>
        <blockquote class="nk-blockquote">
            <div class="nk-blockquote-icon"><span>"</span></div>
            <div class="nk-blockquote-content">
                Just then her head struck against the roof of the hall: in fact she was now more than nine feet high, and she at once took up the little golden key and hurried off to the garden door. As if she had known them all her life. Indeed, she had quite a long argument with the Lory.
            </div>
            <div class="nk-blockquote-author"><span>Samuel Marlow</span></div>
        </blockquote>
        <!-- END: Blockquote -->
    </div>
    <div class="col-lg-5">
        <!-- START: Table -->
        <h3 class="text-main-1">Table</h3>
        <div class="nk-gap"></div>
        <table class="nk-table">
            <thead>
                <tr>
                    <th colspan="3">Skills Table</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Name</th>
                    <th>Game Line</th>
                    <th class="text-center">Percent</th>
                </tr>
                <tr>
                    <td>Duke</td>
                    <td>Top</td>
                    <td class="text-center"><strong>85</strong></td>
                </tr>
                <tr>
                    <td>Bandi</td>
                    <td>Jungle</td>
                    <td class="text-center"><strong>75</strong></td>
                </tr>
                <tr>
                    <td>Faker</td>
                    <td>Mid</td>
                    <td class="text-center"><strong>80</strong></td>
                </tr>
                <tr>
                    <td>Bang</td>
                    <td>ADC</td>
                    <td class="text-center"><strong>99</strong></td>
                </tr>
                <tr>
                    <td>Wolf</td>
                    <td>Support</td>
                    <td class="text-center"><strong>80</strong></td>
                </tr>
            </tbody>
        </table>
        <!-- END: Table -->
    </div>
</div>

<!-- START: Buttons -->
<div class="nk-gap-2"></div>
<h3 class="text-main-1">Buttons</h3>
<div class="nk-gap"></div>
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-main-1">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-info">
    <span class="icon ion-paper-airplane"></span>
    Button
</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-color-primary">
    <span class="nk-btn-effect-bg"></span>
    Button
</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-outline nk-btn-color-success">
    Button
</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-rounded nk-btn-outline nk-btn-color-warning">
    <span>Button</span>
    <span class="icon"><i class="fab fa-css3"></i></span>
</a>

<div class="nk-gap-1"></div>
<a href="#" class="nk-btn nk-btn-xs nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-sm nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-lg nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-x2 nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-x3 nk-btn-rounded nk-btn-color-white">Button</a>
&nbsp;&nbsp;
<a href="#" class="nk-btn nk-btn-x4 nk-btn-rounded nk-btn-color-white">Button</a>
<!-- END: Buttons -->

<!--
    START: Pagination

    Additional Classes:
        .nk-pagination-center
        .nk-pagination-right
-->
<div class="nk-gap-2"></div>
<h3 class="text-main-1">Pagination</h3>
<div class="nk-gap"></div>
<div class="nk-pagination nk-pagination-center">
    <a href="#" class="nk-pagination-prev">
        <span class="ion-ios-arrow-back"></span>
    </a>
    <nav>
        <a class="nk-pagination-current" href="#">1</a>
        <a href="#">2</a>
        <a href="#">3</a>
        <a href="#">4</a>
        <span>...</span>
        <a href="#">14</a>
    </nav>
    <a href="#" class="nk-pagination-next">
        <span class="ion-ios-arrow-forward"></span>
    </a>
</div>
<!-- END: Pagination -->

<!-- START: Features -->
<div class="nk-gap-2"></div>
<h3 class="text-main-1">Features</h3>
<div class="nk-gap"></div>
<div class="row vertical-gap">
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <img src="assets/images/icon-mouse.png" alt="">
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">PC</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <img src="assets/images/icon-gamepad.png" alt="">
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">PS4</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <img src="assets/images/icon-gamepad-2.png" alt="">
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">Xbox</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <span class="ion-help-buoy"></span>
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">Help</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">Get</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <span class="ion-social-rss"></span>
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">News</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">Read</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-1">
            <div class="nk-feature-icon">
                <span class="ion-chatboxes"></span>
            </div>
            <div class="nk-feature-cont">
                <h3 class="nk-feature-title"><a href="#">Forum</a></h3>
                <h3 class="nk-feature-title text-main-1"><a href="#">Join</a></h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <span class="ion-leaf"></span>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title"><span class="text-main-1">Clean</span> and Slick</h3>
                <div class="nk-gap-1"></div>
                This sounded nonsense to Alice, so she said nothing, but set off at once toward the Red Queen. To her surprise.
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <span class="ion-social-twitter"></span>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title"><span class="text-main-1">Social</span> Friendly</h3>
                <div class="nk-gap-1"></div>
                d this she looked down at her hands and was surprised to see that she had put on one of the Rabbit's little white.
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <span class="ion-information-circled"></span>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title"><span class="text-main-1">Well</span> Documented</h3>
                <div class="nk-gap-1"></div>
                I had with my master during the greatest part of the time I had the honour to be in his service.
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <div class="nk-count h2 mb-0">86</div>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title">Projects</h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <div class="nk-count h2 mb-0">640</div>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title">Happy Clients</h3>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-feature-2">
            <div class="nk-feature-icon">
                <div class="nk-count h2 mb-0">47</div>
            </div>
            <div class="nk-feature-cont text-center">
                <h3 class="nk-feature-title">Awards Won</h3>
            </div>
        </div>
    </div>
</div>
<!-- END: Features -->

<!--
    START: Countdown

    Additional Classes:
        .nk-countdown-center
        .nk-countdown-right
-->
<div class="nk-gap-2"></div>
<h3 class="text-main-1">Countdown</h3>
<div class="nk-gap"></div>
<div class="nk-countdown nk-countdown-center" data-end="2018-11-26 08:20" data-timezone="EST"></div>
<!-- END: Countdown -->

<!-- START: Info Boxes -->
<div class="nk-gap-2"></div>
<h3><span class="text-main-1">Info</span> Boxes</h3>
<div class="nk-gap"></div>

<div class="nk-info-box text-danger">
    <div class="nk-info-box-icon">
        <i class="ion-close-round"></i>
    </div>
    <h3>Error!</h3>
    <em>Thing place. In lesser waters creepeth his place us give multiply fruitful under. Make. Also were, you're make make likeness.</em>
</div>
<div class="nk-gap"></div>

<div class="nk-info-box text-success">
    <div class="nk-info-box-icon">
        <i class="ion-checkmark-round"></i>
    </div>
    <h3>Success!</h3>
    <em>Hath days lesser meat signs very. Fruit second can't moved seas meat two. Grass face isn't forth firmament dry. Don't.</em>
</div>
<div class="nk-gap"></div>

<div class="row">
    <div class="col-lg-6">
        <div class="nk-info-box text-info">
            <div class="nk-info-box-icon">
                <i class="ion-information"></i>
            </div>
            <div class="nk-info-box-close nk-info-box-close-btn">
                <i class="ion-close-round"></i>
            </div>
            <h3>Info!</h3>
            <em>Hath days lesser meat signs very. Fruit second can't moved seas meat two. Grass face isn't forth firmament dry. Don't.</em>
            <div class="nk-gap-1"></div>
            <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-info">
                <span>Help Me</span>
                <span class="icon"><i class="ion-help-circled"></i></span>
            </a>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="nk-info-box text-warning">
            <div class="nk-info-box-icon">
                <i class="ion-android-notifications-none"></i>
            </div>
            <div class="nk-info-box-close nk-info-box-close-btn">
                <i class="ion-close-round"></i>
            </div>
            <h3>Notification!</h3>
            <em>Grass his itself. Subdue lesser have without female deep set tree together fourth under brought don't seasons seed saw third.</em>
            <div class="nk-gap-1"></div>
            <a href="#" class="nk-btn nk-btn-rounded nk-btn-outline nk-btn-color-warning">
                Got It
            </a>
        </div>
    </div>
</div>

<div class="nk-info-box nk-info-box-noicon">
    <div class="nk-info-box-close nk-info-box-close-btn">
        <i class="ion-close-round"></i>
    </div>
    <em>No Icon :'(</em>
</div>
<!-- END: Info Boxes -->

<div class="nk-gap-2"></div>
<h3><span class="text-main-1">Audio</span> Player</h3>
<div class="nk-gap"></div>
<!-- START: Plain Audio -->
<div class="nk-audio-plain" data-src="assets/mp3/OctoSound-sport.mp3">
    <div class="nk-audio-plain-title">
        <strong>OctoSound</strong> - Sport
        <div class="nk-audio-progress">
            <div class="nk-audio-progress-current"></div>
        </div>
    </div>
    <div class="nk-audio-plain-duration">
        05:34
    </div>
</div>
<div class="nk-gap-1"></div>
<div class="nk-audio-plain" data-src="assets/mp3/soundroll-total-overdrive.mp3">
    <div class="nk-audio-plain-title">
        <strong>soundroll</strong> - Total Overdrive
        <div class="nk-audio-progress">
            <div class="nk-audio-progress-current"></div>
        </div>
    </div>
    <div class="nk-audio-plain-duration">
        03:59
    </div>
</div>
<!-- END: Plain Audio  -->

<!-- START: Forms -->
<div class="nk-gap-2"></div>
<div class="row vertical-gap">
    <div class="col-lg-6">
        <h3><span class="text-main-1">AJAX</span> Contact Form</h3>
        <div class="nk-gap"></div>
        <form action="php/ajax-contact-form.php" class="nk-form nk-form-ajax">
            <div class="row vertical-gap sm-gap">
                <div class="col-md-6">
                    <input type="email" class="form-control required" name="email" placeholder="Email *">
                </div>
                <div class="col-md-6">
                    <input type="text" class="form-control required" name="name" placeholder="Name *">
                </div>
            </div>
            <div class="nk-gap"></div>
            <textarea class="form-control required" name="message" rows="5" placeholder="Message *"></textarea>
            <div class="nk-gap-1"></div>
            <button class="nk-btn nk-btn-rounded nk-btn-color-dark-3">
                <span>Send</span>
                <span class="icon"><i class="ion-paper-airplane"></i></span>
            </button>
            <div class="nk-form-response-success"></div>
            <div class="nk-form-response-error"></div>
        </form>

        <div class="nk-gap-2"></div>
        <h3><span class="text-main-1">Other</span> Controls</h3>
        <div class="nk-gap"></div>
        <form action="#" class="nk-form">
            <div class="row">
                <div class="col-md-6">
                    <select name="select" class="form-control">
                        <option value="" disabled selected>Select a Country</option>
                        <option value="1">Russian Federation</option>
                        <option value="2">USA</option>
                        <option value="3">United Kingdom</option>
                        <option value="4">France</option>
                        <option value="5">Spain</option>
                        <option value="6">Germany</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <div class="mt-7"></div>
                    <div class="nk-rating">
                        <input type="radio" id="review-rate-5" name="review-rate" value="5">
                        <label for="review-rate-5">
                            <span><i class="far fa-star"></i></span>
                            <span><i class="fa fa-star"></i></span>
                        </label>

                        <input type="radio" id="review-rate-4" name="review-rate" value="4">
                        <label for="review-rate-4">
                            <span><i class="far fa-star"></i></span>
                            <span><i class="fa fa-star"></i></span>
                        </label>

                        <input type="radio" id="review-rate-3" name="review-rate" value="3">
                        <label for="review-rate-3">
                            <span><i class="far fa-star"></i></span>
                            <span><i class="fa fa-star"></i></span>
                        </label>

                        <input type="radio" id="review-rate-2" name="review-rate" value="2">
                        <label for="review-rate-2">
                            <span><i class="far fa-star"></i></span>
                            <span><i class="fa fa-star"></i></span>
                        </label>

                        <input type="radio" id="review-rate-1" name="review-rate" value="1">
                        <label for="review-rate-1">
                            <span><i class="far fa-star"></i></span>
                            <span><i class="fa fa-star"></i></span>
                        </label>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="col-lg-6">
        <h3><span class="text-main-1">MailChimp</span> Form 1</h3>
        <div class="nk-gap"></div>
        <!-- START: MailChimp Signup Form -->
        <form action="//nkdev.us11.list-manage.com/subscribe/post?u=d433160c0c43dcf8ecd52402f&amp;id=7eafafe8f0" method="post" class="nk-mchimp validate" target="_blank">
            <div class="input-group">
                <input type="email" value="" name="EMAIL" class="required email form-control" placeholder="Email *">
                <button class="nk-btn nk-btn-color-dark-3">Subscribe</button>
            </div>
            <div class="nk-form-response-success"></div>
            <div class="nk-form-response-error"></div>
            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
            <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_d433160c0c43dcf8ecd52402f_7eafafe8f0" tabindex="-1" value=""></div>
        </form>
        <!-- END: MailChimp Signup Form -->

        <div class="nk-gap-2"></div>
        <h3><span class="text-main-1">MailChimp</span> Form 2</h3>
        <div class="nk-gap"></div>
        <!-- START: MailChimp Signup Form -->
        <form action="//nkdev.us11.list-manage.com/subscribe/post?u=d433160c0c43dcf8ecd52402f&amp;id=7eafafe8f0" method="post" class="nk-mchimp nk-form nk-form-style-1 validate" target="_blank">
            <div class="input-group">
                <input type="email" value="" name="EMAIL" class="required email form-control" placeholder="Email *">
                <button class="nk-btn nk-btn-color-white">Subscribe</button>
            </div>
            <small>We'll never share your email with anyone else.</small>
            <div class="nk-form-response-success"></div>
            <div class="nk-form-response-error"></div>
            <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
            <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_d433160c0c43dcf8ecd52402f_7eafafe8f0" tabindex="-1" value=""></div>
        </form>
        <!-- END: MailChimp Signup Form -->

        <div class="nk-gap-2"></div>
        <h3><span class="text-main-1">Search</span> Form</h3>
        <div class="nk-gap"></div>
        <!-- START: Search Form -->
        <form action="#" method="post" class="nk-form nk-form-style-1">
            <div class="input-group">
                <input type="text" name="s" class="form-control" placeholder="Type something">
                <button class="nk-btn nk-btn-color-main-1">
                    <span class="fa fa-search"></span>
                </button>
            </div>
        </form>
        <!-- END: Search Form -->
    </div>
</div>
<!-- END: Forms -->

<!-- START: Content Grid -->
<div class="nk-gap-2"></div>
<h3><span class="text-main-1">Content</span> Grid</h3>
<div class="nk-gap"></div>
<div class="row vertical-gap text-white">
    <div class="col-lg-6">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself, and to the trust I reposed in you.
        </div>
    </div>
    <div class="col-lg-6">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself, and to the trust I reposed in you.
        </div>
    </div>
    <div class="col-lg-9">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself, and to the trust I reposed in you. However, many of the most learned and
        </div>
    </div>
    <div class="col-lg-3">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper
        </div>
    </div>
    <div class="col-lg-12">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself, and to the trust I reposed in you. However, many of the most learned and wise adhere to the new scheme of expressing themselves by things;
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself
        </div>
    </div>
    <div class="col-lg-4">
        <div class="nk-box-2 bg-dark-2">
            <h4>Thus Much</h4>
            Thus much I thought proper to tell you in relation to yourself
        </div>
    </div>
</div>
<!-- END: Content Grid -->
</div>

<div class="nk-gap-2"></div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/pages/elements.blade.php ENDPATH**/ ?>