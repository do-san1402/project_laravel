
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
       Thông tin khách hàng
        </div>
        <div class="row w3-res-tb">
        
        <div class="col-sm-4">
        </div>
        
        </div>
        <div class="table-responsive">
           <?php
                $status = session() -> get('message_all');
                    if($status) {
                        echo " <div class='alert alert-success' role='alert'>$status</div>";
                        session() -> put('message_all', null); 
                    }
              
            ?> 
        <table class="table table-striped b-t b-light">
            <thead>
            <tr>
                <th style="width:20px;">
                <label class="i-checks m-b-none">
                    <input type="checkbox"><i></i>
                </label>
                </th>
                <th>Tên</th>
                <th>Số điện thoại</th>
                <th>Email</th>
                
                <th style="width:30px;"></th>
            </tr>
            </thead>
            <tbody>
           
            <tr>
                <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->phone); ?></td>
                <td><?php echo e($customer->email); ?></td>
                
                
            </tr>
         
            </tbody>
        </table>
        
        </div>
        
    </div>
    <br>
    <div class="panel panel-default">
        <div class="panel-heading">
       Thông tin vận chuyển
        </div>
        <div class="row w3-res-tb">
        
        <div class="col-sm-4">
        </div>
        
        </div>
        <div class="table-responsive">
           
        <table class="table table-striped b-t b-light">
            <thead>
            <tr>
                <th style="width:20px;">
                <label class="i-checks m-b-none">
                    <input type="checkbox"><i></i>
                </label>
                </th>
                <th>Tên người vận chuyển</th>
                <th>Số điện thoại</th>
                <th>Địa chỉ</th>
                <th>Email</th>
                <th>Ghi chú</th>
                <th>Hình thức thanh toán</th>                
                
                
                <th style="width:30px;"></th>
            </tr>
            </thead>
            <tbody>
           
            <tr>
                <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
                <td><?php echo e($shipping->name_shipping); ?></td>
                <td><?php echo e($shipping->phone_shipping); ?></td>
                <td><?php echo e($shipping->address_shipping); ?></td>
                <td><?php echo e($shipping->email_shipping); ?></td>
                <td><?php echo e($shipping->notes_shipping); ?></td>
                <td><?php if($shipping->shopping_method == 0): ?>
                        Chuyển khoản
                    <?php else: ?>
                        Tiền mặc
                    <?php endif; ?>
                </td>
                
            </tr>
         
            </tbody>
        </table>
        
        </div>
        
    </div>
</div>
<br><br>



<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
       Chi tiết đơn hàng 
        </div>
        <div class="row w3-res-tb">
        
        <div class="col-sm-4">
        </div>
        
        </div>
        <div class="table-responsive">
           
        <table class="table table-striped b-t b-light">
            <thead>
            <tr>
                <th>STT</th>
                <th>Tên sản phẩm</th>
                <th>Số lượng hàng tồn</th>
                <th>Mã giảm giá</th>
                <th>Phí giao hàng</th>
                <th>Số lượng</th>
                <th>Giá</th>
                <th>Tổng tiền</th>
             
            
                
                <th style="width:30px;"></th>
            </tr>
            </thead>
            <tbody>
            <?php
                $stt = 0 ;  
                $total = 0;
                foreach($order_detail as $key => $ord) {
                    $stt++;
                    $subtotal = $ord->product_price*$ord->product_sales_qty;
                    $total += $subtotal;
                    ?>
                        <tr class="color_qty_<?php echo e($ord->product_id); ?>">
                            <td><?php echo e($stt); ?></td>
                            <td><?php echo e($ord->product_name); ?></td>
                            <td><?php echo e($ord->product->product_quantity); ?></td>
                            <td>
                                <?php if($ord->product_coupon !='0'): ?>
                                    <?php echo e($ord->product_coupon); ?>

                                <?php else: ?>
                                    Không mã
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e(number_format($ord->product_feeship)); ?>VND
                            </td>
                            <td >
                               <input type="number" min="1" <?php echo e($order_status==2 ? 'disabled': ''); ?> class="order_qty_<?php echo e($ord->product_id); ?>" value="<?php echo e($ord->product_sales_qty); ?>" name="product_sales_qty">

                                <input type="hidden" name="order_qty_storage" class="order_qty_storage_<?php echo e($ord->product_id); ?>" value="<?php echo e($ord->product->product_quantity); ?>">

                               <input type="hidden" name="order_code" class="order_code" value="<?php echo e($ord->order_code); ?>">

                               <input type="hidden" name="product_qty_id" class="product_qty_id" value="<?php echo e($ord->product_id); ?>">
                                <?php if($order_status !=2): ?>
                                    <button class="btn btn-default update_quantity_order" name="update_quantity_order" data-product_id="<?php echo e($ord->product_id); ?>">Cập nhật</button>
                               <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e(number_format($ord->product_price)); ?>VND
                            </td>
                            
                            <td><?php echo e(number_format($subtotal)); ?>VND </td>
                            
                        </tr>
                    <?php
                }
            ?>
            <tr>
                <td></td>
                <td >
                    <?php
                        if($coupon_conditions == 0) {
                            $total_after_coupon = ($total*$coupon_option)/100;
                            echo 'Tổng giảm: '.number_format($total_after_coupon).' VND';
                            $total_coupon = $total - $total_after_coupon + $ord->product_feeship;
                        }else {
                            echo 'Tổng giảm: '.number_format($coupon_option).' VND';
                            $total_coupon = $total - $coupon_option + $ord->product_feeship;
                        }
                    ?>
                <br>
          
                  Tổng phí giao hàng: <?php echo e(number_format($ord->product_feeship)); ?>VND <br>
                  Tổng:  <?php echo e(number_format($total_coupon)); ?>VND
                </td>
            </tr>
            <tr >
                <td colspan="3"> 
                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $or): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php if($or->order_status == 1): ?>
                            <form action="">
                                <?php echo csrf_field(); ?>
                                <select class="form-control order_detail"name="" id="">
                                    <option id="<?php echo e($or->id); ?>" value="1" selected>Đơn hàng mới</option>
                                    <option id="<?php echo e($or->id); ?>" value="2">Đã xử lý-đã giao hàng</option>
                                    <option id="<?php echo e($or->id); ?>" value="3">Hủy đơn hàng- tạm giữ</option>
                                </select>
                            </form>
                        <?php elseif($or->order_status == 2): ?>
                            <form action="">
                                <select class="form-control order_detail"name="" id="">
                                    <option id="<?php echo e($or->id); ?>"value="1">Đơn hàng mới</option>
                                    <option id="<?php echo e($or->id); ?>" value="2" selected>Đã xử lý-đã giao hàng</option>
                                    <option id="<?php echo e($or->id); ?>" value="3">Hủy đơn hàng- tạm giữ</option>
                                </select>
                            </form>
                        <?php else: ?>
                            <form action="">
                                <select class="form-control order_detail"name="" id="">
                                    <option id="<?php echo e($or->id); ?>"value="1">Đơn hàng mới</option>
                                    <option id="<?php echo e($or->id); ?>" value="2" >Đã xử lý-đã giao hàng</option>
                                    <option id="<?php echo e($or->id); ?>" value="3" selected>Hủy đơn hàng- tạm giữ</option>
                                </select>
                            </form>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            
         
            </tbody>
        </table>
        </div>
    </div>
    <a target="_blank" href="<?php echo e(url('/print-order/'.$ord->order_code)); ?>">In đơn hàng</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/admin/edit_order.blade.php ENDPATH**/ ?>