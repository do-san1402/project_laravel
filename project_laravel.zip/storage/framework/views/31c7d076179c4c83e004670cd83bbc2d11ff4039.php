
<?php $__env->startSection('main'); ?>
<div class="nk-main">
        
    <!-- START: Breadcrumbs -->
<div class="nk-gap-1"></div>
<div class="container">
<ul class="nk-breadcrumbs">


<li><a href="index.html">Home</a></li>


<li><span class="fa fa-angle-right"></span></li>

<li><a href="store.html">Store</a></li>


<li><span class="fa fa-angle-right"></span></li>

<li><span>Action Games</span></li>

</ul>
</div>
<div class="nk-gap-1"></div>
<!-- END: Breadcrumbs -->




<div class="container">

<!-- START: Image Slider -->
<div class="nk-image-slider" data-autoplay="8000">


<div class="nk-image-slider-item">
    <img src="assets/images/slide-1.jpg" alt="" class="nk-image-slider-img" data-thumb="assets/images/slide-1-thumb.jpg">
    
    <div class="nk-image-slider-content">
        
<h3 class="h4">As we Passed, I remarked</h3>
<p class="text-white">As we passed, I remarked a beautiful church-spire rising above some old elms in the park; and before them, in the midst of a lawn, chimneys covered with ivy, and the windows shining in the sun.</p>
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white nk-btn-hover-color-main-1">Read More</a>

    </div>
    
</div>

<div class="nk-image-slider-item">
    <img src="assets/images/slide-2.jpg" alt="" class="nk-image-slider-img" data-thumb="assets/images/slide-2-thumb.jpg">
    
    <div class="nk-image-slider-content">
        
<h3 class="h4">He made his passenger captain of one</h3>
<p class="text-white">Now the races of these two have been for some ages utterly extinct, and besides to discourse any further of them would not be at all to my purpose. But the concern I have most at heart is for our Corporation of Poets, from whom I am preparing a petition to your Highness,  to be subscribed with the names of one...</p>
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white nk-btn-hover-color-main-1">Read More</a>

    </div>
    
</div>

<div class="nk-image-slider-item">
    <img src="assets/images/slide-3.jpg" alt="" class="nk-image-slider-img" data-thumb="assets/images/slide-3-thumb.jpg">
    
</div>

<div class="nk-image-slider-item">
    <img src="assets/images/slide-4.jpg" alt="" class="nk-image-slider-img" data-thumb="assets/images/slide-4-thumb.jpg">
    
    <div class="nk-image-slider-content">
        
<h3 class="h4">At length one of them called out in a clear</h3>
<p class="text-white">TJust then her head struck against the roof of the hall: in fact she was now more than nine feet high...</p>
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white nk-btn-hover-color-main-1">Read More</a>

    </div>
    
</div>

<div class="nk-image-slider-item">
    <img src="assets/images/slide-5.jpg" alt="" class="nk-image-slider-img" data-thumb="assets/images/slide-5-thumb.jpg">
    
    <div class="nk-image-slider-content">
        
<h3 class="h4">For good, too though, in consequence</h3>
<p class="text-white">She gave my mother such a turn, that I have always been convinced I am indebted to Miss Betsey for having been born on a Friday. The word was appropriate to the moment.</p>
<p class="text-white">My mother was so much worse that Peggotty, coming in with the teaboard and candles, and seeing at a glance how ill she was, - as Miss Betsey might have done sooner if there had been light enough, - conveyed her upstairs to her own room with all speed; and immediately dispatched Ham Peggotty, her nephew, who had been for some days past secreted in the house...</p>
<a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white nk-btn-hover-color-main-1">Read More</a>

    </div>
    
</div>

</div>
<!-- END: Image Slider -->

<!-- START: Categories -->
<div class="nk-gap-2"></div>
<div class="row vertical-gap">
<div class="col-lg-4">
    <div class="nk-feature-1">
        <div class="nk-feature-icon">
            <img src="assets/images/icon-mouse.png" alt="">
        </div>
        <div class="nk-feature-cont">
            <h3 class="nk-feature-title"><a href="#">PC</a></h3>
            <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
        </div>
    </div>
</div>
<div class="col-lg-4">
    <div class="nk-feature-1">
        <div class="nk-feature-icon">
            <img src="assets/images/icon-gamepad.png" alt="">
        </div>
        <div class="nk-feature-cont">
            <h3 class="nk-feature-title"><a href="#">PS4</a></h3>
            <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
        </div>
    </div>
</div>
<div class="col-lg-4">
    <div class="nk-feature-1">
        <div class="nk-feature-icon">
            <img src="assets/images/icon-gamepad-2.png" alt="">
        </div>
        <div class="nk-feature-cont">
            <h3 class="nk-feature-title"><a href="#">Xbox</a></h3>
            <h3 class="nk-feature-title text-main-1"><a href="#">View Games</a></h3>
        </div>
    </div>
</div>
</div>
<!-- END: Categories -->

<div class="nk-gap-2"></div>
<div class="row vertical-gap">
<div class="col-lg-8">
    <!-- START: Products -->
    <div class="row vertical-gap">
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-1-xs.jpg" alt="So saying he unbuckled">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">So saying he unbuckled</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 23.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-2-xs.jpg" alt="However, I have reason">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">However, I have reason</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="2.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i> <i class="far fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 32.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-3-xs.jpg" alt="It was some time before">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">It was some time before</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 14.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-4-xs.jpg" alt="She was bouncing">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">She was bouncing</a></h3>
                    <div class="nk-gap-1"></div>
                    
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 20.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-5-xs.jpg" alt="In all revolutions of">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">In all revolutions of</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 23.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-6-xs.jpg" alt="Just then her head ">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">Just then her head </a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="3"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 32.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-7-xs.jpg" alt="With what mingled joy">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">With what mingled joy</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="3.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 14.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-8-xs.jpg" alt="She was bouncing away">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">She was bouncing away</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 20.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-9-xs.jpg" alt="The word was">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">The word was</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 23.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-10-xs.jpg" alt="My mother was so much">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">My mother was so much</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="3.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 32.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-11-xs.jpg" alt="She gave my mother">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">She gave my mother</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="3"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 14.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-12-xs.jpg" alt="A hundred thousand">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">A hundred thousand</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 20.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-13-xs.jpg" alt="So saying he unbuckled">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">So saying he unbuckled</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 23.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-14-xs.jpg" alt="However, I have reason">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">However, I have reason</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="1.5"> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i> <i class="far fa-star"></i> <i class="far fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 32.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-15-xs.jpg" alt="At first, for some time">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">At first, for some time</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 14.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="nk-product-cat">
                <a class="nk-product-image" href="store-product.html">
                    <img src="assets/images/product-16-xs.jpg" alt="When the last &#39;natural&#39;">
                </a>
                <div class="nk-product-cont">
                    <h3 class="nk-product-title h5"><a href="store-product.html">When the last &#39;natural&#39;</a></h3>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-rating" data-rating="4.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i></div>
                    <div class="nk-gap-1"></div>
                    <div class="nk-product-price">€ 20.00</div>
                    <div class="nk-gap-1"></div>
                    <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-dark-3 nk-btn-hover-color-main-1">Add to Cart</a>
                </div>
            </div>
        </div>
        
    </div>
    <!-- END: Products -->

    <!-- START: Pagination -->
    <div class="nk-gap-3"></div>
    <div class="nk-pagination nk-pagination-center">
        <a href="#" class="nk-pagination-prev">
            <span class="ion-ios-arrow-back"></span>
        </a>
        <nav>
            <a class="nk-pagination-current" href="#">1</a>
            <a href="#">2</a>
            <a href="#">3</a>
            <a href="#">4</a>
            <span>...</span>
            <a href="#">14</a>
        </nav>
        <a href="#" class="nk-pagination-next">
            <span class="ion-ios-arrow-forward"></span>
        </a>
    </div>
    <!-- END: Pagination -->
</div>
<div class="col-lg-4">
    <!--
        START: Sidebar

        Additional Classes:
            .nk-sidebar-left
            .nk-sidebar-right
            .nk-sidebar-sticky
    -->
    <aside class="nk-sidebar nk-sidebar-right nk-sidebar-sticky">
        <div class="nk-widget">
<div class="nk-widget-content">
<form action="#" class="nk-form nk-form-style-1" novalidate="novalidate">
    <div class="input-group">
        <input type="text" class="form-control" placeholder="Type something...">
        <button class="nk-btn nk-btn-color-main-1"><span class="ion-search"></span></button>
    </div>
</form>
</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span><span class="text-main-1">Category</span> Menu</span></h4>
<div class="nk-widget-content">
<ul class="nk-widget-categories">
    <li><a href="#">RTS</a></li>
    <li><a href="#">Action</a></li>
    <li><a href="#">RPG</a></li>
    <li><a href="#">MMO</a></li>
    <li><a href="#">MOBA</a></li>
    <li><a href="#">Adventure</a></li>
    <li><a href="#">Indie</a></li>
    <li><a href="#">Strategy</a></li>
    <li><a href="#">Racing</a></li>
    <li><a href="#">Simulator</a></li>
</ul>
</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span><span class="text-main-1">Price</span> Filter</span></h4>
<div class="nk-widget-content">
<div class="nk-input-slider">
    <input
        type="text"
        name="price-filter"
        data-slider-min="0"
        data-slider-max="1800"
        data-slider-step="1"
        data-slider-value="[200, 1200]"
        data-slider-tooltip="hide"
    >
    <div class="nk-gap"></div>
    <div>
        <div class="text-white mt-4 float-left">
            PRICE:
            <strong class="text-main-1">€ <span class="nk-input-slider-value-0"></span></strong>
            -
            <strong class="text-main-1">€ <span class="nk-input-slider-value-1"></span></strong>
        </div>
        <a href="#" class="nk-btn nk-btn-rounded nk-btn-color-white float-right">Apply</a>
    </div>
    <div class="clearfix"></div>
</div>
</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span><span class="text-main-1">We</span> Are Social</span></h4>
<div class="nk-widget-content">
<!--
    Social Links 3

    Additional Classes:
        .nk-social-links-cols-5
        .nk-social-links-cols-4
        .nk-social-links-cols-3
        .nk-social-links-cols-2
-->
<ul class="nk-social-links-3 nk-social-links-cols-4">
    <li><a class="nk-social-twitch" href="#"><span class="fab fa-twitch"></span></a></li>
    <li><a class="nk-social-instagram" href="#"><span class="fab fa-instagram"></span></a></li>
    <li><a class="nk-social-facebook" href="#"><span class="fab fa-facebook"></span></a></li>
    <li><a class="nk-social-google-plus" href="#"><span class="fab fa-google-plus"></span></a></li>
    <li><a class="nk-social-youtube" href="#"><span class="fab fa-youtube"></span></a></li>
    <li><a class="nk-social-twitter" href="#" target="_blank"><span class="fab fa-twitter"></span></a></li>
    <li><a class="nk-social-pinterest" href="#"><span class="fab fa-pinterest-p"></span></a></li>
    <li><a class="nk-social-rss" href="#"><span class="fa fa-rss"></span></a></li>

    <!-- Additional Social Buttons
        <li><a class="nk-social-behance" href="#"><span class="fab fa-behance"></span></a></li>
        <li><a class="nk-social-bitbucket" href="#"><span class="fab fa-bitbucket"></span></a></li>
        <li><a class="nk-social-dropbox" href="#"><span class="fab fa-dropbox"></span></a></li>
        <li><a class="nk-social-dribbble" href="#"><span class="fab fa-dribbble"></span></a></li>
        <li><a class="nk-social-deviantart" href="#"><span class="fab fa-deviantart"></span></a></li>
        <li><a class="nk-social-flickr" href="#"><span class="fab fa-flickr"></span></a></li>
        <li><a class="nk-social-foursquare" href="#"><span class="fab fa-foursquare"></span></a></li>
        <li><a class="nk-social-github" href="#"><span class="fab fa-github"></span></a></li>
        <li><a class="nk-social-linkedin" href="#"><span class="fab fa-linkedin"></span></a></li>
        <li><a class="nk-social-medium" href="#"><span class="fab fa-medium"></span></a></li>
        <li><a class="nk-social-odnoklassniki" href="#"><span class="fab fa-odnoklassniki"></span></a></li>
        <li><a class="nk-social-paypal" href="#"><span class="fab fa-paypal"></span></a></li>
        <li><a class="nk-social-reddit" href="#"><span class="fab fa-reddit"></span></a></li>
        <li><a class="nk-social-skype" href="#"><span class="fab fa-skype"></span></a></li>
        <li><a class="nk-social-soundcloud" href="#"><span class="fab fa-soundcloud"></span></a></li>
        <li><a class="nk-social-steam" href="#"><span class="fab fa-steam"></span></a></li>
        <li><a class="nk-social-slack" href="#"><span class="fab fa-slack"></span></a></li>
        <li><a class="nk-social-tumblr" href="#"><span class="fab fa-tumblr"></span></a></li>
        <li><a class="nk-social-vimeo" href="#"><span class="fab fa-vimeo"></span></a></li>
        <li><a class="nk-social-vk" href="#"><span class="fab fa-vk"></span></a></li>
        <li><a class="nk-social-wordpress" href="#"><span class="fab fa-wordpress"></span></a></li>
    -->
</ul>
</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span><span class="text-main-1">Most</span> Popular</span></h4>
<div class="nk-widget-content">

<div class="nk-widget-post">
    <a href="store-product.html" class="nk-post-image">
        <img src="assets/images/product-1-xs.jpg" alt="So saying he unbuckled">
    </a>
    <h3 class="nk-post-title"><a href="store-product.html">So saying he unbuckled</a></h3>
    <div class="nk-product-rating" data-rating="4"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="far fa-star"></i></div>
    <div class="nk-product-price">€ 23.00</div>
</div>

<div class="nk-widget-post">
    <a href="store-product.html" class="nk-post-image">
        <img src="assets/images/product-2-xs.jpg" alt="However, I have reason">
    </a>
    <h3 class="nk-post-title"><a href="store-product.html">However, I have reason</a></h3>
    <div class="nk-product-rating" data-rating="2.5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fas fa-star-half"></i> <i class="far fa-star"></i> <i class="far fa-star"></i></div>
    <div class="nk-product-price">€ 32.00</div>
</div>

<div class="nk-widget-post">
    <a href="store-product.html" class="nk-post-image">
        <img src="assets/images/product-3-xs.jpg" alt="It was some time before">
    </a>
    <h3 class="nk-post-title"><a href="store-product.html">It was some time before</a></h3>
    <div class="nk-product-rating" data-rating="5"> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i> <i class="fa fa-star"></i></div>
    <div class="nk-product-price">€ 14.00</div>
</div>

</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span>Instagram</span></h4>
<div class="nk-widget-content">
<div class="nk-instagram row sm-gap vertical-gap multi-column"></div>
</div>
</div>
<div class="nk-widget nk-widget-highlighted">
<h4 class="nk-widget-title"><span>Our Twitter</span></h4>
<div class="nk-widget-content">
<div class="nk-twitter-list" data-twitter-count="2"></div>
</div>
</div>

    </aside>
    <!-- END: Sidebar -->
</div>
</div>
</div>

<div class="nk-gap-2"></div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/pages/store-catalog.blade.php ENDPATH**/ ?>