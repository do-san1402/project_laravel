
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Thêm danh sản phẩm
                </header>
                <?php
                    $status = session() -> get('message_success');
                    if($status) {
                        echo " <div class='alert alert-success' role='alert'>$status</div>";
                        session() -> put('message_success', null);
                    }
                       
                ?>
                
                
                
                <div class="panel-body">
                    <div class="position-center">
                        <form role="form" action="<?php echo e(url('product-create')); ?>" method="post"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên sản phẩm</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_name" >
                            <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">SL sản phẩm</label>
                            <input type="number" class="form-control" id="exampleInputEmail1"  name="product_quantity" >
                            <?php $__errorArgs = ['product_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Giá sản phẩm</label>
                            <input type="number" class="form-control" id="exampleInputEmail1"  name="product_price" >
                            <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Ảnh đại diện sản phẩm</label>
                            <input type="file" class="form-control" id="exampleInputEmail1"  name="product_image" >
                            <?php $__errorArgs = ['product_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Ảnh sản phẩm 1</label>
                            <input type="file" class="form-control" id="exampleInputEmail1"  name="product_image_sp_1" >
                            <?php $__errorArgs = ['product_image_sp_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Ảnh sản phẩm 2</label>
                            <input type="file" class="form-control" id="exampleInputEmail1"  name="product_image_sp_2" >
                            <?php $__errorArgs = ['product_image_sp_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Ảnh sản phẩm 3</label>
                            <input type="file" class="form-control" id="exampleInputEmail1"  name="product_image_sp_3" >
                            <?php $__errorArgs = ['product_image_sp_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">CPU</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_cpu" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Ram</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_ram" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Ổ cứng</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_hard_drive" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Card đồ họa</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_graphics_card" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Màn hình</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_screen" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Cổng kết nối</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_connector" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Âm thanh</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_sound" >
                        </div>
                       
                        <div class="form-group">
                            <label for="exampleInputEmail1">Bàn phím</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_keyboard" >
                        </div>
                  
                        <div class="form-group">
                            <label for="exampleInputEmail1">Chuẩn LAN</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_lan" >
                        </div>
                    
                        <div class="form-group">
                            <label for="exampleInputEmail1">Chuẩn WIFI</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_wifi" >
                        </div>
                      
                        <div class="form-group">
                            <label for="exampleInputEmail1">Bluetooth</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_bluetooth" >
                        </div>
                  
                        <div class="form-group">
                            <label for="exampleInputEmail1">Webcam</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_webcam" >
                        </div>
                 
                
                        <div class="form-group">
                            <label for="exampleInputEmail1">Hệ điều hành</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_operating_system" >
                        </div>
                    
                        <div class="form-group">
                            <label for="exampleInputEmail1">PIN</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_pin" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Trọng lượng</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_weight" >
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Màu sắc</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_color" >
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Kích thước</label>
                            <input type="text" class="form-control" id="exampleInputEmail1"  name="product_size" >
                        </div>



                      
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mô tả sản phẩm</label>
                            <textarea type="text" name="product_desc" class="form-control" id="exampleInputPassword1" rows="10" ></textarea>
                            <?php $__errorArgs = ['product_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Từ khóa danh mục</label>
                            <textarea type="text" name="meta_keyword" class="form-control" id="exampleInputPassword1" ></textarea>
                            <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group">
                            <label for="exampleInputEmail1">Danh mục sản phẩm</label>
                            <select class="form-control m-bot15" name="product_category">
                                <option>---Chọn---</option>
                                <?php $__currentLoopData = $category_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($value ->id); ?>'><?php echo e($value ->category_name); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                                
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Thương hiệu sản phẩm</label>
                            <select class="form-control m-bot15" name="product_brand">
                                <option>---Chọn---</option>
                                <?php $__currentLoopData = $brand_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value='<?php echo e($value ->id); ?>'><?php echo e($value ->brand_name); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Hiển thị</label>
                            <select class="form-control m-bot15" name="product_status">
                                <option>---Chọn---</option>
                                <option value='0'>Ẩn</option>
                                <option value='1'>Hiện</option>
                                
                            </select>
                            <?php $__errorArgs = ['product_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <small class="form-text text-danger">
                                <?php echo e($message); ?>

                            </small>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" name="add_product" class="btn btn-info">Thêm sản phẩm</button>
                    </form>
                    </div>

                </div>
            </section>

    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/admin/add_product.blade.php ENDPATH**/ ?>