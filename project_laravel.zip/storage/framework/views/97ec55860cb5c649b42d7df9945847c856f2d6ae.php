
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                   Cập nhật danh mục sản phẩm
                </header>
              
                
                
                <div class="panel-body">
                    <div class="position-center">
                        <?php $__currentLoopData = $category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form role="form" action="<?php echo e(url('/category-product-update/'.$value->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                       
                
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tên danh mục</label>
                                <input type="text" class="form-control" id="exampleInputEmail1"  name="categoty_product_name" placeholder="Enter email" value="<?php echo e($value->category_name); ?>" >
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Mô tả danh mục</label>
                                <input type="text" name="categoty_product_desc" class="form-control" id="exampleInputPassword1" placeholder="Mô tả danh mục"  value="<?php echo e($value->category_desc); ?>"></input>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Từ khóa danh mục</label>
                                <input type="text" class="form-control" id="exampleInputEmail1"  name="meta_keyword" placeholder="Từ khóa danh mục" value="<?php echo e($value->meta_keyword); ?>" >
                            </div>
                            
                       
                            
                       
                        <button type="submit" name="update_category_product" class="btn btn-info">Cập nhật danh mục</button>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </section>

    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/admin/edit_category_product.blade.php ENDPATH**/ ?>