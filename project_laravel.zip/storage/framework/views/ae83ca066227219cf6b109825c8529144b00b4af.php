<?php echo e($slot); ?>

<?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>