
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
        Danh sách đơn hàng
        </div>
        <div class="row w3-res-tb">
        
        <div class="col-sm-4">
        </div>
        
        </div>
        <div class="table-responsive">
            <?php
                $status = session() -> get('message_all');
                    if($status) {
                        echo " <div class='alert alert-success' role='alert'>$status</div>";
                        session() -> put('message_all', null); 
                    }
              
            ?> 
        <table class="table table-striped b-t b-light">
            <thead>
            <tr>
                
                <th>STT</th>
                <th>Mã đơn hàng</th>
                <th>Thời gian đặt hàng</th>
                <th>Tình trạng đơn hàng</th>
                <th style="width:30px;"></th>
            </tr>
            </thead>
            <tbody>
            <?php
                $stt = 0;
            ?>
            <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $stt++;
            ?>
            <tr>
                <td><?php echo e($stt); ?></td>
                <td><?php echo e($ord ->order_code); ?></td>
                <td><?php echo e($ord ->created_at); ?></td>
                <td>
                    
                    <?php if($ord->order_status == 1): ?> 
                        Đơn hàng mới
                    <?php elseif($ord->order_status == 2): ?>
                       Đã giao
                    <?php else: ?>
                        Đã hũy
                    <?php endif; ?>
                </td>
                
                
                
                    



               
                <td>
                    <a href="<?php echo e(url('/edit-order/'.$ord ->order_code)); ?>" class="active" ui-toggle-class="">
                        <i class="fa fa-check text-success text-active"></i>
                    </a>
                    <a href="<?php echo e(url('/delete-order/'.$ord->order_code)); ?>" onclick="return confirm('Bạn có chắc xóa sản phẩm này?')" class="active" ui-toggle-class="">
                      
                        <i class="fa-solid fa-delete-left"></i>
                    </a>
                </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\back-end\laravelPro\project_laravel\resources\views/admin/manager_order.blade.php ENDPATH**/ ?>